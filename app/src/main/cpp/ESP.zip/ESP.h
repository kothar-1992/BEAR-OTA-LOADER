// Forward declaration to resolve linker error
std::string GetPackageName();

int DrawInt()
{
   // py = ScreenY/2;
   // px = ScreenX/2;
    return 0;
}
int xWidth =50;
int xtWidth =10;

int hpWidth = 50;
int hpHeight = 8;

int scWidth = 220;
int scHeight = 110;

int qtWidth = 220;
int qtHeight = 50;

int iconsize = 50;






void DrawESP(ImDrawList *draw) {
   int Wj_rs = 10;
   int Rj_rs = 15;
    
    

 if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
     
     
 if (!strcmp(GetPackageName().c_str(), "com.bearmod")) {
         
       
            
            int playerCount = 0, robotCount = 0;
      //  draw->AddImage(Base64Image[1].textureId, ImVec2(glWidth / 2-95, 40), ImVec2(glWidth / 2-95, 115), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
      //  draw->AddImage(Base64Image[2].textureId, ImVec2(glWidth / 2+95, 40), ImVec2(glWidth / 2+95, 115), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
            
        draw->AddImage(Base64Image[1].textureId, ImVec2(glWidth / 2-115 - 50 / 2, 115), ImVec2(glWidth / 2-115 + 50 / 2, 115 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
        draw->AddImage(Base64Image[2].textureId, ImVec2(glWidth / 2+115 - 50 / 2, 115), ImVec2(glWidth / 2+115 + 50 / 2, 115 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
         if (playerCount == 0 && robotCount == 0) {
        draw->AddImage(Base64Image[3].textureId, ImVec2(glWidth / 2 - 50 / 2, 114), ImVec2(glWidth / 2 + 50 / 2, 114 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
         }else{
         
        if(robotCount == 0){
            draw->AddTextX(ImVec2(glWidth / 2 + 36.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255),45, std::to_string(robotCount).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 + 35, 100 + 50 / 2 - 5), ImColor(0, 255, 0), 45, std::to_string(robotCount).c_str());
           }else{
        draw->AddTextX(ImVec2(glWidth / 2 + 36.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255),45, std::to_string(robotCount).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 + 35, 100 + 50 / 2 - 5), ImColor(255, 255, 0), 45, std::to_string(robotCount).c_str());
                draw->AddImage(Base64Image[4].textureId, ImVec2(glWidth / 2 - 50 / 2, 114), ImVec2(glWidth / 2 + 50 / 2, 114 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
        }
         if(playerCount == 0){
             draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(playerCount).c_str(), 40) - 33.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255), 45, std::to_string(playerCount).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(playerCount).c_str(), 40) - 35, 100 + 50 / 2 - 5), ImColor(0, 255, 0), 45, std::to_string(playerCount).c_str());
                  }else{
                      draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(playerCount).c_str(), 40) - 33.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255), 45, std::to_string(playerCount).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(playerCount).c_str(), 40) - 35, 100 + 50 / 2 - 5), ImColor(255, 0, 0), 45, std::to_string(playerCount).c_str());
                draw->AddImage(Base64Image[5].textureId, ImVec2(glWidth / 2 - 50 / 2, 114), ImVec2(glWidth / 2 + 50 / 2, 114 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
                      }
        }
        
        
             //   draw->AddImage(RenderImage[2].textureId,{glWidth /2-120,40},{glWidth /2+120,180},ImVec2(0, 0),ImVec2(1, 1),ImColor(255, 255, 255,255));
                
            std::string str1;
            str1 += "Safe";
            auto Size1 = ImGui::CalcTextSize(str1.c_str(), 0, 36);

     }

     

          if (!Config.Handcam){
        

  
 if (!bScanPatternCompleted)
      return;
    
              auto GWorld = GetWorld();
    if (GWorld) {
        ULevel *PersistentLevel = GWorld->PersistentLevel;
        if (GWorld->PersistentLevel) {
           TArray<AActor *> Actors = *(TArray<AActor *> *)((uintptr_t)PersistentLevel + 0xA0);
//auto GWorld = GetWorld();
//  if (Canvas) {

    auto localPlayer = g_LocalPlayer;
       auto localPlayerController = g_LocalController;

  int totalEnemies = 0, totalBots = 0;
   if (localPlayerController == 0){
  //LOGO
Config.OutfitEnable = false;
   } else {
          
          }
if (localPlayerController && localPlayer)
{
    
UGameplayStatics *gGameplayStatics = (UGameplayStatics *)UGameplayStatics::StaticClass();


                    for (int i = 0; i < Actors.Num(); i++) {
                    if (isObjectPlayer(Actors[i])) {
                        auto Player = (ASTExtraPlayerCharacter *) Actors[i];
                        auto RootComponent = Player->RootComponent;
                        if (!RootComponent)
                            continue;
      
      
 
                          if (localPlayer) {
                            if (Player->PlayerKey == localPlayer->PlayerKey)
                                continue;

                            if (Player->TeamID == localPlayer->TeamID)
                                continue;
                        }
             
if (Player->bDead)
    continue;
    
            
if (Player->bHidden)
    continue;
    
if (!Player->Mesh)
continue;
/*
if (Player->Health < 0.0f || Player->Health > 10000000.0f ) { continue; }

   */
   
                     // Improved ESP alert logic: safer, clearer, less buggy, more robust

                     // Hide bots if configured
                     if (Config.EspHideBot && Player->bEnsure) {
                         continue;
                     }

                     // Count bots and enemies
                     if (Player->bEnsure) {
                         totalBots++;
                     } else {
                         totalEnemies++;
                     }

                     // Set ESP colors based on bot/enemy
                     int ColorEspAlert = Player->bEnsure
                         ? IM_COL32(154, 255, 60, 225)
                         : IM_COL32(171, 0, 169, 225);
                     int HPCOLOR = Player->bEnsure
                         ? IM_COL32(0, 255, 47, 255)
                         : IM_COL32(255, 30, 0, 255);

                     // Calculate distance (avoid division by zero)
                     float Distance = 0.0f;
                     if (localPlayer) {
                         Distance = Player->GetDistanceTo(localPlayer) / 100.f;
                     }

                     // Only show alert if within range and enabled
                     if (Distance < 1000.f && Config.Alert) {
                         bool isRadarOut = false;
                         FVector MyPosition, EnemyPosition;

                         // Get Player position (prefer vehicle if available)
                         if (Player->CurrentVehicle && Player->CurrentVehicle->RootComponent) {
                             MyPosition = Player->CurrentVehicle->RootComponent->RelativeLocation;
                         } else if (Player->RootComponent) {
                             MyPosition = Player->RootComponent->RelativeLocation;
                         } else {
                             MyPosition = FVector(); // fallback
                         }

                         // Get localPlayer position (prefer vehicle if available)
                         if (localPlayer->CurrentVehicle && localPlayer->CurrentVehicle->RootComponent) {
                             EnemyPosition = localPlayer->CurrentVehicle->RootComponent->RelativeLocation;
                         } else if (localPlayer->RootComponent) {
                             EnemyPosition = localPlayer->RootComponent->RelativeLocation;
                         } else {
                             EnemyPosition = FVector(); // fallback
                         }

                         // Calculate radar position
                         // Fix: WorldToRadar expects (float yaw, FVector entity, FVector local, float posX, float posY, Vector3 size, bool& outbuff)
                         // Define radar variables for this calculation
                         Vector3 radarPos;
                         Vector3 radarSize;
                         radarSize.X = 170.0f;
                         radarSize.Y = 170.0f;
                         radarPos.X = glWidth / 5.5f;
                         radarPos.Y = glHeight / 4.1f;
                         
                         FVector EntityPos = WorldToRadar(
                             localPlayerController->PlayerCameraManager->CameraCache.POV.Rotation.Yaw,
                             EnemyPosition,
                             MyPosition,
                             radarPos.X, radarPos.Y,
                             Vector3(radarSize.X, radarSize.Y, 0),
                             isRadarOut
                         );

                         // Calculate angle and triangle points
                         FVector angle;
                         Vector3 forward(
                             static_cast<float>(glWidth) / 2.f - EntityPos.X,
                             static_cast<float>(glHeight) / 2.f - EntityPos.Y,
                             0.0f
                         );
                         VectorAnglesRadar(forward, angle);

                         const float angle_yaw_rad = DEG2RAD(angle.Y + 180.f);
                         const float base_radius = 75.f * 4.f; // 75/2*8 = 300, but let's clarify
                         const float new_point_x = (glWidth / 2.f) + base_radius * cosf(angle_yaw_rad);
                         const float new_point_y = (glHeight / 2.f) + base_radius * sinf(angle_yaw_rad);

                         // Triangle size constants
                         const float tri_w = (45.f / 4.f + 3.5f) / 2.f;
                         const float tri_h = (55.f / 4.f + 3.5f) / 2.f;
                         const float tri_w2 = (45.f / 4.f + 3.5f) / 4.f;

                         std::array<Vector3, 3> points{
                             Vector3(new_point_x - tri_w, new_point_y - tri_h, 0.f),
                             Vector3(new_point_x + tri_w2, new_point_y, 0.f),
                             Vector3(new_point_x - tri_w, new_point_y + tri_h, 0.f)
                         };
                         RotateTriangle(points, angle.Y + 180.f);

                         // Try to project head location to screen
                         auto AboveHead = Player->GetHeadLocation(true);
                         FVector2D AboveHeadSc;
                         bool projected = false;
                         if (gGameplayStatics) {
                             projected = gGameplayStatics->ProjectWorldToScreen(
                                 localPlayerController, AboveHead, false, &AboveHeadSc
                             );
                         }

                         // If not on screen, draw alert triangle at radar edge
                         if (!projected) {
                             draw->AddTriangleFilled(
                                 ImVec2(points.at(0).X, points.at(0).Y),
                                 ImVec2(points.at(1).X, points.at(1).Y),
                                 ImVec2(points.at(2).X, points.at(2).Y),
                                 ColorEspAlert
                             );
                             draw->AddTriangle(
                                 ImVec2(points.at(0).X, points.at(0).Y),
                                 ImVec2(points.at(1).X, points.at(1).Y),
                                 ImVec2(points.at(2).X, points.at(2).Y),
                                 IM_COL32(0, 0, 0, 255), 18.18f
                             );
                             draw->AddTriangle(
                                 ImVec2(points.at(0).X, points.at(0).Y),
                                 ImVec2(points.at(1).X, points.at(1).Y),
                                 ImVec2(points.at(2).X, points.at(2).Y),
                                 ColorEspAlert, 15.18f
                             );
                         }
                     }

                        

if (Config.RadarMap) {
    // Use local variables instead of static for position/size to avoid bugs with multiple calls/players
    Vector3 radarPos;
    Vector3 radarSize;
    radarSize.X = 170.0f;
    radarSize.Y = 170.0f;

    // Calculate radar position dynamically based on screen size
    radarPos.X = glWidth / 5.5f;
    radarPos.Y = glHeight / 4.1f;

    float radarCenterX = radarPos.X + (radarSize.X * 0.5f);
    float radarCenterY = radarPos.Y + (radarSize.Y * 0.5f);

    ImColor lineColor(255, 255, 255, 255);
    ImColor pointColor(255, 0, 0, 255);
    float transparentBoxSize = 160.0f;
    ImColor backgroundColor(0, 0, 0, 115);
    ImColor transparentBoxColor = backgroundColor;

    // Draw radar background (centered box)
    ImVec2 boxMin(
        radarPos.X - (transparentBoxSize - radarSize.X) * 0.5f,
        radarPos.Y - (transparentBoxSize - radarSize.Y) * 0.5f
    );
    ImVec2 boxMax(
        radarPos.X + radarSize.X + (transparentBoxSize - radarSize.X) * 0.5f,
        radarPos.Y + radarSize.Y + (transparentBoxSize - radarSize.Y) * 0.5f
    );
    draw->AddRectFilled(boxMin, boxMax, transparentBoxColor, 0.0f, 0);

    // Draw radar border
    draw->AddRect(ImVec2(radarPos.X, radarPos.Y), ImVec2(radarPos.X + radarSize.X, radarPos.Y + radarSize.Y), lineColor, 0.0f, 0, 1.0f);

    // Draw cross lines
    draw->AddLine(ImVec2(radarCenterX, radarPos.Y), ImVec2(radarCenterX, radarPos.Y + radarSize.Y), lineColor, 1.0f);
    draw->AddLine(ImVec2(radarPos.X, radarCenterY), ImVec2(radarPos.X + radarSize.X, radarCenterY), lineColor, 1.0f);

    // Draw radar center point
    draw->AddCircleFilled(ImVec2(radarCenterX, radarCenterY), 3.0f, lineColor, 32);

    // Defensive: Check pointers before use
    if (Player && Player->RootComponent && localPlayer && localPlayer->RootComponent && localPlayerController && localPlayerController->PlayerCameraManager) {
        FVector myPosition = Player->RootComponent->RelativeLocation;
        FVector enemyPosition = localPlayer->RootComponent->RelativeLocation;

        bool out = false;
        FVector radarPoint = WorldToRadar(
            localPlayerController->PlayerCameraManager->CameraCache.POV.Rotation.Yaw,
            myPosition, enemyPosition,
            radarPos.X, radarPos.Y, radarSize, out
        );

        // Clamp radar point to radar bounds to avoid drawing outside
        float clampedX = std::max(radarPos.X, std::min(radarPos.X + radarSize.X, radarPoint.X));
        float clampedY = std::max(radarPos.Y, std::min(radarPos.Y + radarSize.Y, radarPoint.Y));

        // Only draw if within distance and inside radar
        if (Distance >= 0.0f && Distance < 500.0f && !out) {
            draw->AddCircleFilled(ImVec2(clampedX, clampedY), 3.0f, ColorEspAlert, 16);
        }
    }
}


                        // Improved and safer ESP bone/line color logic and bone fetching

                        // Use ImU32 for color, not long. Use const for default colors.
                        const ImU32 kBoneVisibleColor = IM_COL32(255, 0, 0, 255);
                        const ImU32 kBoneNotVisibleColor = IM_COL32(0, 255, 0, 255);
                        const ImU32 kLineVisibleColor = IM_COL32(0, 255, 0, 255);
                        const ImU32 kLineNotVisibleColor = IM_COL32(255, 255, 255, 255);

                        ImU32 boneColor = kBoneVisibleColor;
                        ImU32 lineColor = kLineVisibleColor;

                        // Defensive: Check pointers before use
                        if (localPlayerController && Player) {
                            // Use player's head for visibility check, not {0,0,0}
                            FVector headPos = Player->GetBonePos("Head", {});
                            if (!localPlayerController->LineOfSightTo(Player, headPos, true)) {
                                boneColor = kBoneNotVisibleColor;
                            }

                            // Use correct arguments for LineOfSightTo
                            if (localPlayerController->PlayerCameraManager) {
                                FVector headLoc = GetBoneLocation(Player, "Head");
                                if (!localPlayerController->LineOfSightTo(Player, headLoc, true)) {
                                    lineColor = kLineNotVisibleColor;
                                }
                            }
                        }

                        // Helper lambda to fetch bone safely
                        auto safeGetBone = [Player](const char* name) -> FVector {
                            if (Player) return Player->GetBonePos(name, {});
                            return FVector{0,0,0};
                        };

                        // Fetch all bones safely
                        FVector Head = safeGetBone("Head");
                        FVector Root = safeGetBone("Root");
                        FVector uparmr = safeGetBone("upperarm_r");
                        FVector uparml = safeGetBone("upperarm_l");
                        FVector lowarmr = safeGetBone("lowerarm_r");
                        FVector lowarml = safeGetBone("lowerarm_l");
                        FVector handr = safeGetBone("hand_r");
                        FVector handl = safeGetBone("hand_l");
                        FVector itemr = safeGetBone("item_r");
                        FVector iteml = safeGetBone("item_l");
                        FVector clavicler = safeGetBone("clavicle_r");
                        FVector claviclel = safeGetBone("clavicle_l");
                        FVector neck = safeGetBone("neck_01");
                        FVector spain01 = safeGetBone("spine_01");
                        FVector spain02 = safeGetBone("spine_02");
                        FVector spain03 = safeGetBone("spine_03");
                        FVector pelvis = safeGetBone("pelvis");
                        FVector calfl = safeGetBone("calf_l");
                        FVector calfr = safeGetBone("calf_r");
                        FVector thighl = safeGetBone("thigh_l");
                        FVector thighr = safeGetBone("thigh_r");
                        FVector footr = safeGetBone("foot_r");
                        FVector footl = safeGetBone("foot_l");

                        // Defensive: Check PlayerCameraManager before use
                        if (localPlayerController && localPlayerController->PlayerCameraManager) {
                            auto PlayerCameraManager = localPlayerController->PlayerCameraManager;
                            CameraCache = PlayerCameraManager->CameraCache;
                            FVector HeadNrg = GetBoneLocationByName(Player, "Head");
                            FVector2D HeadNrgSc = WorldToScreen360(HeadNrg, CameraCache.POV);
                            // HeadNrgSc is now ready for use
                        }
             
                            
                       // Improved ESP Line and Box Drawing Logic

                       // Draw ESP line from screen center to enemy head
                       if (Config.EspLine) {
                           // Clamp distance to avoid negative/overflow values
                           float safeDistance = std::max(1.0f, std::min(Distance, 10000.0f));
                           float mWidthScaleGun = std::min(0.006f * safeDistance, 100.f);
                           float mWidthGun = std::max(1.0f, 20.f - mWidthScaleGun);
                           float mHeightGun = mWidthGun * 0.125f;

                       // Initialize all bone screen positions to zero for safety
                       ImVec2 HeadSc{}, uparmrSC{}, uparmlSC{}, lowarmrSC{}, lowarmlSC{}, handrSC{}, handlSC{}, itemrSC{}, itemlSC{}, upperarmtwist01rSC{}, upperarmtwist01lSC{}, claviclerSC{}, claviclelSC{}, neckSC{}, spain01SC{}, spain02SC{}, spain03SC{}, pelvisSC{};

                           // Defensive: Only adjust if HeadSc is valid
                           ImVec2 lineTarget = HeadSc;
                           lineTarget.y -= (mHeightGun * 1.4f + 15.0f + 21.0f);

                           // Defensive: Clamp lineTarget to screen bounds
                           lineTarget.x = std::max(0.0f, std::min(lineTarget.x, (float)glWidth));
                           lineTarget.y = std::max(0.0f, std::min(lineTarget.y, (float)glHeight));

                           draw->AddLine(
                               ImVec2((float)glWidth / 2.0f, 140.0f),
                               lineTarget,
                               lineColor,
                               1.7f
                           );
                       }
                       ImVec2 RootSc{}, calflSC{}, calfrSC{}, thighlSC{}, thighrSC{}, calftwist01lSC{}, calftwist01rSC{}, thightwist01lSC{}, thightwist01rSC{}, footrSC{}, footlSC{}, lowerarmtwist01lSC{}, lowerarmtwist01rSC{};

                       // Only draw box if all required bones are valid and on screen
                       bool allBonesVisible =
                           WorldToScreenBone(Head, (FVector2D*)&HeadSc) &&
                           WorldToScreenBone(Root, (FVector2D*)&RootSc) &&
                           WorldToScreenBone(uparmr, (FVector2D*)&uparmrSC) &&
                           WorldToScreenBone(uparml, (FVector2D*)&uparmlSC) &&
                           WorldToScreenBone(lowarml, (FVector2D*)&lowarmlSC) &&
                           WorldToScreenBone(lowarmr, (FVector2D*)&lowarmrSC) &&
                           WorldToScreenBone(handr, (FVector2D*)&handrSC) &&
                           WorldToScreenBone(handl, (FVector2D*)&handlSC) &&
                           WorldToScreenBone(itemr, (FVector2D*)&itemrSC) &&
                           WorldToScreenBone(iteml, (FVector2D*)&itemlSC) &&
                           WorldToScreenBone(clavicler, (FVector2D*)&claviclerSC) &&
                           WorldToScreenBone(claviclel, (FVector2D*)&claviclelSC) &&
                           WorldToScreenBone(neck, (FVector2D*)&neckSC) &&
                           WorldToScreenBone(spain01, (FVector2D*)&spain01SC) &&
                           WorldToScreenBone(spain02, (FVector2D*)&spain02SC) &&
                           WorldToScreenBone(spain03, (FVector2D*)&spain03SC) &&
                           WorldToScreenBone(pelvis, (FVector2D*)&pelvisSC) &&
                           WorldToScreenBone(calfl, (FVector2D*)&calflSC) &&
                           WorldToScreenBone(calfr, (FVector2D*)&calfrSC) &&
                           WorldToScreenBone(thighl, (FVector2D*)&thighlSC) &&
                           WorldToScreenBone(thighr, (FVector2D*)&thighrSC) &&
                           WorldToScreenBone(footr, (FVector2D*)&footrSC) &&
                           WorldToScreenBone(footl, (FVector2D*)&footlSC);

                       if (allBonesVisible && Config.Box) {
                           // Defensive: Use fabsf for float abs, clamp boxHeight
                           float boxHeight = std::max(1.0f, fabsf(HeadSc.y - RootSc.y));
                           float boxWidth = std::max(1.0f, boxHeight * 0.65f);

                           // Clamp box to screen bounds
                           ImVec2 vStart = { std::max(0.0f, HeadSc.x - (boxWidth / 2.0f)), std::max(0.0f, HeadSc.y) };
                           ImVec2 vEnd = { std::min((float)glWidth, vStart.x + boxWidth), std::min((float)glHeight, vStart.y + boxHeight) };

                           // Use configurable color if available, else fallback to white
                           ImU32 boxColor = (Config.BoxColor != 0) ? Config.BoxColor : IM_COL32(255, 255, 255, 255);

                           draw->AddRect(vStart, vEnd, boxColor, 1.5f, 0, 1.7f);
                           // Optionally: draw->AddRectFilled(vStart, vEnd, PlayerBoxClrCf2, 1.5f, 0);
                       }

                        
                        
                              // Improved, less buggy, and more maintainable bone ESP drawing
                              if (Config.EspBone) {
                                  struct BoneLine {
                                      ImVec2* from;
                                      ImVec2* to;
                                      FVector fromWorld;
                                      FVector toWorld;
                                  };

                                  // Array of bone connections (screen positions and world positions)
                                  BoneLine boneLines[] = {
                                      { &HeadSc,     &neckSC,      Head,      neck },
                                      { &neckSC,     &claviclerSC, neck,      clavicler },
                                      { &claviclerSC,&uparmrSC,    clavicler, uparmr },
                                      { &uparmrSC,   &lowarmrSC,   uparmr,    lowarmr },
                                      { &lowarmrSC,  &handrSC,     lowarmr,   handr },
                                      { &handrSC,    &itemrSC,     handr,     itemr },
                                      { &neckSC,     &claviclelSC, neck,      claviclel },
                                      { &claviclelSC,&uparmlSC,    claviclel, uparml },
                                      { &uparmlSC,   &lowarmlSC,   uparml,    lowarml },
                                      { &lowarmlSC,  &handlSC,     lowarml,   handl },
                                      { &handlSC,    &itemlSC,     handl,     iteml },
                                      { &neckSC,     &spain03SC,   neck,      spain03 },
                                      { &spain03SC,  &spain02SC,   spain03,   spain02 },
                                      { &spain02SC,  &spain01SC,   spain02,   spain01 },
                                      { &spain01SC,  &pelvisSC,    spain01,   pelvis },
                                      { &pelvisSC,   &thighrSC,    pelvis,    thighr },
                                      { &thighrSC,   &calfrSC,     thighr,    calfr },
                                      { &calfrSC,    &footrSC,     calfr,     footr },
                                      { &pelvisSC,   &thighlSC,    pelvis,    thighl },
                                      { &thighlSC,   &calflSC,     thighl,    calfl },
                                      { &calflSC,    &footlSC,     calfl,     footl }
                                  };

                                  // Defensive: Check controller and camera manager
                                  if (!localPlayerController || !localPlayerController->PlayerCameraManager)
                                      return;

                                  // Draw all bone lines with LOS color
                                  for (const auto& bone : boneLines) {
                                      // Defensive: Check for valid screen pointers
                                      if (!bone.from || !bone.to)
                                          continue;

                                      // Defensive: Check for valid screen coordinates (not zeroed)
                                      if ((bone.from->x == 0.0f && bone.from->y == 0.0f) ||
                                          (bone.to->x == 0.0f && bone.to->y == 0.0f))
                                          continue;

                                      // Defensive: Check for valid world positions (optional, if possible)
                                      // (Assume world positions are always valid for now)

                                      bool hasLOS = localPlayerController->LineOfSightTo(
                                          localPlayerController->PlayerCameraManager, bone.toWorld, true);

                                      ImU32 color = hasLOS ? IM_COL32(0, 255, 0, 255) : IM_COL32(255, 0, 0, 255);

                                      draw->AddLine(
                                          ImVec2(bone.from->x, bone.from->y),
                                          ImVec2(bone.to->x, bone.to->y),
                                          color,
                                          2.0f
                                      );
                                  }
                              }
                        //    if (Config.styleESP == 2) {
                            
                               // Improved Health Bar Drawing: safer, clearer, less buggy

                               if (Config.Health) {
                                   // Defensive: Validate Player and HealthMax
                                   int maxHealth = (Player && Player->HealthMax > 0) ? (int)Player->HealthMax : 100;
                                   int curHealth = (Player) ? (int)Player->Health : 0;

                                   // Clamp current health to [0, maxHealth]
                                   curHealth = std::max(0, std::min(curHealth, maxHealth));

                                   ImU32 hpColor = IM_COL32(200, 0, 0, 90);
                                   ImU32 hpBorderColor = IM_COL32(200, 0, 0, 120);

                                   // If bot, use green fill, red border (original logic seems reversed, but preserved)
                                   if (Player && Player->bEnsure) {
                                       hpColor = IM_COL32(0, 200, 0, 90);
                                       hpBorderColor = IM_COL32(200, 0, 0, 120);
                                   }

                                   // Handle "knocked" state (NearDeath)
                                   if (Player && Player->Health == 0.0f && !Player->bDead) {
                                       curHealth = (Player->NearDeathBreath > 0) ? Player->NearDeathBreath : 0;
                                       if (Player->NearDeatchComponent && Player->NearDeatchComponent->BreathMax > 0) {
                                           maxHealth = Player->NearDeatchComponent->BreathMax;
                                       } else {
                                           maxHealth = 100;
                                       }
                                       hpColor = IM_COL32(255, 255, 255, 90);
                                       hpBorderColor = IM_COL32(255, 255, 255, 120);
                                   }

                                   // Defensive: avoid division by zero
                                   if (maxHealth <= 0) maxHealth = 1;

                                   // Health bar width (fixed at 100, can be scaled if needed)
                                   const float barWidth = 100.0f;
                                   const float barHeight = 20.0f;
                                   float healthWidth = barWidth * (float(curHealth) / float(maxHealth));
                                   healthWidth = std::max(0.0f, std::min(healthWidth, barWidth));

                                   // Bar polygon points (hexagonal style)
                                   ImVec2 p0(HeadSc.x - 50, HeadSc.y - 10);
                                   ImVec2 p1(HeadSc.x - 50 + healthWidth, HeadSc.y - 10);
                                   ImVec2 p2(HeadSc.x - 50 + healthWidth + 9, HeadSc.y - 20);
                                   ImVec2 p3(HeadSc.x - 50 + healthWidth, HeadSc.y - 30);
                                   ImVec2 p4(HeadSc.x - 50, HeadSc.y - 30);
                                   ImVec2 p5(HeadSc.x - 50 - 9, HeadSc.y - 20);

                                   // Draw filled health bar
                                   draw->PathClear();
                                   draw->PathLineTo(p0);
                                   draw->PathLineTo(p1);
                                   draw->PathLineTo(p2);
                                   draw->PathLineTo(p3);
                                   draw->PathLineTo(p4);
                                   draw->PathLineTo(p5);
                                   draw->PathFillConvex(hpColor);

                                   // Draw border (full bar outline)
                                   ImVec2 b1(HeadSc.x - 50 + barWidth, HeadSc.y - 10);
                                   ImVec2 b2(HeadSc.x - 50 + barWidth + 9, HeadSc.y - 20);
                                   ImVec2 b3(HeadSc.x - 50 + barWidth, HeadSc.y - 30);

                                   draw->PathClear();
                                   draw->PathLineTo(p0);
                                   draw->PathLineTo(b1);
                                   draw->PathLineTo(b2);
                                   draw->PathLineTo(b3);
                                   draw->PathLineTo(p4);
                                   draw->PathLineTo(p5);
                                   draw->PathStroke(hpBorderColor, ImDrawFlags_Closed, 2.5f);
                               }
                         
                               // Improved: safer, clearer, and less buggy name/team rendering

                               // Draw player name if enabled
                               if (Config.Name) {
                                   // Calculate box width based on distance, clamp to avoid negative/zero
                                   float baseBoxWidth = 464.0f / 1.6f;
                                   float distanceFactor = std::max(1.0f, Distance); // Avoid division by zero
                                   float shrink = std::min((baseBoxWidth / 2.0f) / 100.0f * distanceFactor, baseBoxWidth / 2.0f);
                                   float boxWidth = std::max(40.0f, baseBoxWidth - shrink); // Minimum width
                                   float boxHeight = boxWidth * 0.15f;

                                   std::string s;
                                   if (Player->bEnsure) {
                                       s = "      BOT";
                                   } else {
                                       // Defensive: check for valid name, truncate if too long
                                       std::string playerName = Player->PlayerName.ToString();
                                       if (playerName.empty()) playerName = "Unknown";
                                       const size_t maxNameLen = 24;
                                       if (playerName.length() > maxNameLen)
                                           playerName = playerName.substr(0, maxNameLen) + "...";
                                       s = playerName;
                                   }

                                   // Draw name with shadow for readability
                                   ImVec2 namePos(HeadSc.x - (boxWidth / 3.3f), HeadSc.y - (boxHeight * 1.48f));
                                   ImU32 nameColor = IM_COL32(255, 255, 255, 255);
                                   ImU32 shadowColor = IM_COL32(0, 0, 0, 180);
                                   // Shadow
                                   draw->AddText(Chinese, 23.0f, {namePos.x + 1, namePos.y + 1}, shadowColor, s.c_str());
                                   // Main text
                                   draw->AddText(Chinese, 23.0f, namePos, nameColor, s.c_str());
                               }

                               // Draw team ID if enabled
                               if (Config.TeamId) {
                                   std::string s = "Team: " + std::to_string(Player->TeamID);
                                   ImColor teamColor(255, 200, 0, 255);
                                   int textX = static_cast<int>(HeadSc.x - 45);
                                   int textY = static_cast<int>(HeadSc.y - 58);
                                   // Defensive: clamp position to screen if needed (optional)
                                   Fly_Draw->DrawStrokeText(textX, textY, teamColor, s.c_str());
                               }
                            
                    
                         
                            
   // Improved, safer, and less buggy weapon icon rendering

   // Improved, safer, and less buggy weapon icon rendering logic

   if (Config.Weapon) {
       // Defensive: check all pointers before use
       auto WeaponManagerComponent = Player ? Player->WeaponManagerComponent : nullptr;
       ASTExtraShootWeapon* CurrentWeaponReplicated = nullptr;
       int weaponId = 0;

       if (WeaponManagerComponent) {
           CurrentWeaponReplicated = reinterpret_cast<ASTExtraShootWeapon*>(WeaponManagerComponent->CurrentWeaponReplicated);
           if (CurrentWeaponReplicated) {
               weaponId = CurrentWeaponReplicated->GetWeaponID();
           }
       }

       // Helper: draw icon at head position, with fallback to RootSc if head not available
       auto DrawWeaponIcon = [&](const TextureInfo& textureInfo) {
           FVector2D imageHeadSc;
           if (!WorldToScreenBone(Head, &imageHeadSc)) {
               // Fallback: use RootSc if Head not available
               imageHeadSc.X = RootSc.x;
               imageHeadSc.Y = RootSc.y;
           }
           ImVec4 rect((imageHeadSc.X) - 80, imageHeadSc.Y - 50, 160, 25);
           draw->AddImage(textureInfo.textureId, ImVec2(imageHeadSc.X + 50, rect.y - 41), ImVec2(imageHeadSc.X - 70, rect.y));
       };

       // Helper: check if weaponId matches any in a list
       auto IsWeaponVariant = [](int wId, const std::initializer_list<int>& ids) -> bool {
           for (int id : ids) {
               if (wId == id) return true;
           }
           return false;
       };

       // Table of weapon icon entries (consolidated, deduplicated)
       struct WeaponIconEntry {
           std::initializer_list<int> ids;
           TextureInfo* textureInfo;
       };

       static const WeaponIconEntry weaponIconTable[] = {
           // ARs
           { {101001, 1010011, 1010012, 1010013, 1010014, 1010015, 1010016, 1010017}, &ID101001 }, // AKM
           { {101002, 1010021, 1010022, 1010023, 1010024, 1010025, 1010026, 1010027}, &ID101002 }, // M16A4
           { {101003, 1010031, 1010032, 1010033, 1010034, 1010035, 1010036, 1010037}, &ID101003 }, // SCAR-L
           { {101004, 1010041, 1010042, 1010043, 1010044, 1010045, 1010046, 1010047}, &ID101004 }, // M416
           { {101005, 1010051, 1010052, 1010053, 1010054, 1010055, 1010056, 1010057}, &ID101005 }, // Groza
           { {101006, 1010061, 1010062, 1010063, 1010064, 1010065, 1010066, 1010067}, &ID101006 }, // AUG A3
           { {101007, 1010071, 1010072, 1010073, 1010074, 1010075, 1010076, 1010077}, &ID101007 }, // QBZ
           { {101008, 1010081, 1010082, 1010083, 1010084, 1010085, 1010086, 1010087}, &ID101008 }, // M762
           { {101009, 1010091, 1010092, 1010093, 1010094, 1010095, 1010096, 1010097}, &ID101009 }, // Mk47
           { {101010, 1010101, 1010102, 1010103, 1010104, 1010105, 1010106, 1010107}, &ID101010 }, // G36C
           { {101100, 1011001, 1011002, 1011003, 1011004, 1011005, 1011006, 1011007}, &NFAMAS }, // FAMAS
           { {101102, 1011021, 1011022, 1011023, 1011024, 1011025, 1011026, 1011027}, &NACE32 }, // ACE32

           // SMGs
           { {102001, 1020011, 1020012, 1020013, 1020014, 1020015}, &ID102001 }, // UZI
           { {102002, 1020021, 1020022, 1020023, 1020024, 1020025}, &ID102002 }, // UMP45
           { {102003, 1020031, 1020032, 1020033, 1020034, 1020035, 1020036, 1020037}, &ID102003 }, // Vector
           { {102004, 1020041, 1020042, 1020043, 1020044, 1020045, 1020046, 1020047}, &ID102004 }, // Thompson
           { {102005, 1020051, 1020052, 1020053, 1020054, 1020055, 1020056, 1020057}, &ID102005 }, // Bizon
           { {102105, 1021051, 1021052, 1021053, 1021054, 1021055, 1021056, 1021057}, &ID102105 }, // MP5K
           { {102007, 1020071, 1020072, 1020073, 1020074, 1020075, 1020076, 1020077}, &ID102007 }, // Skorpion
           { {106008, 1060081, 1060082, 1060083, 1060084, 1060085, 1060086, 1060087}, &NVz61 }, // Vz61

           // DMRs/Snipers
           { {103001, 1030011, 1030012, 1030013, 1030014, 1030015, 1030016, 1030017}, &hand.KAR98K }, // Kar98K
           { {103002, 1030021, 1030022, 1030023, 1030024, 1030025, 1030026, 1030027}, &ID103002 }, // M24
           { {103003, 1030031, 1030032, 1030033, 1030034, 1030035, 1030036, 1030037}, &ID103003 }, // AWM
           { {103004, 1030041, 1030042, 1030043, 1030044, 1030045, 1030046, 1030047}, &ID103004 }, // SKS
           { {103005, 1030051, 1030052, 1030053, 1030054, 1030055, 1030056, 1030057}, &ID103005 }, // VSS
           { {103006, 1030061, 1030062, 1030063, 1030064, 1030065, 1030066, 1030067}, &ID103006 }, // Mini14
           { {103007, 1030071, 1030072, 1030073, 1030074, 1030075, 1030076, 1030077}, &ID103007 }, // Mk14
           { {103008, 1030081, 1030082, 1030083, 1030084, 1030085, 1030086, 1030087}, &ID103008 }, // Win94
           { {103009, 1030091, 1030092, 1030093, 1030094, 1030095, 1030096, 1030097}, &hand.SLR }, // SLR
           { {103010, 1030101, 1030102, 1030103, 1030104, 1030105, 1030106, 1030107}, &ID103010 }, // QBU
           { {103011, 1030111, 1030112, 1030113, 1030114, 1030115, 1030116, 1030117}, &ID103011 }, // Mosin
           { {103012, 1030121, 1030122, 1030123, 1030124, 1030125, 1030126, 1030127}, &ID103012 }, // AMR
           { {103100, 1031001, 1031002, 1031003, 1031004, 1031005, 1031006, 1031007}, &NMk12 }, // Mk12

           // Shotguns
           { {104001, 1040011, 1040012, 1040013, 1040014, 1040015, 1040016, 1040017}, &ID104001 }, // S686
           { {104002, 1040021, 1040022, 1040023, 1040024, 1040025, 1040026, 1040027}, &ID104002 }, // S1897
           { {104003, 1040031, 1040032, 1040033, 1040034, 1040035, 1040036, 1040037}, &ID104003 }, // S12K
           { {104004, 1040041, 1040042, 1040043, 1040044, 1040045, 1040046, 1040047}, &ID104004 }, // DPS

           // LMGs
           { {105001, 1050011, 1050012, 1050013, 1050014, 1050015, 1050016, 1050017}, &ID105001 }, // M249
           { {105002, 1050021, 1050022, 1050023, 1050024, 1050025, 1050026, 1050027}, &ID105002 }, // DP-28

           // Pistols
           { {106001, 1060011, 1060012, 1060013, 1060014, 1060015, 1060016, 1060017}, &hand.P92 }, // P92
           { {106002, 1060021, 1060022, 1060023, 1060024, 1060025, 1060026, 1060027}, &hand.P1911 }, // P1911
           { {106003, 1060031, 1060032, 1060033, 1060034, 1060035, 1060036, 1060037}, &hand.R1895 }, // R1895
           { {106004, 1060041, 1060042, 1060043, 1060044, 1060045, 1060046, 1060047}, &hand.P18C }, // P18C
           { {106005, 1060051, 1060052, 1060053, 1060054, 1060055, 1060056, 1060057}, &hand.R45 }, // R45
           { {106010, 1060101, 1060102, 1060103, 1060104, 1060105, 1060106, 1060107}, &NDesertEagle }, // Desert Eagle

           // Melee
           { {108001, 1080011, 1080012, 1080013, 1080014, 1080015, 1080016, 1080017}, &ID大砍刀 }, // Machete
           { {108002, 1080021, 1080022, 1080023, 1080024, 1080025, 1080026, 1080027}, &ID撬棍 }, // Crowbar
           { {108003, 1080031, 1080032, 1080033, 1080034, 1080035, 1080036, 1080037}, &ID镰刀 }, // Sickle
           { {108004, 1080041, 1080042, 1080043, 1080044, 1080045, 1080046, 1080047}, &hand.PAN }, // Pan

           // Crossbow
           { {107001, 1070011, 1070012, 1070013, 1070014, 1070015, 1070016, 1070017}, &ID107001 }, // Crossbow

           // Throwables
           { {602004}, &ID手雷弹 }, // Frag Grenade
           { {602002}, &ID烟雾弹 }, // Smoke Grenade
           { {602001}, &ID震撼弹 }, // Stun Grenade
           { {602003}, &ID燃烧瓶 }, // Molotov

           // Special/other
           { {106006, 1060061, 1060062, 1060063, 1060064, 1060065, 1060066, 1060067}, &hand.Sawed_off }, // Sawed-off
       };

       // Defensive: treat invalid/unknown weaponId as "fist"
       bool foundWeaponIcon = false;
       if (weaponId <= 0 || weaponId >= 10008611) {
           DrawWeaponIcon(ID拳头);
           foundWeaponIcon = true;
       } else {
           // Special case: Pan (unique icon logic)
           if (weaponId == 108005) {
               FVector2D imageHeadSc;
               if (!WorldToScreenBone(Head, &imageHeadSc)) {
                   imageHeadSc.X = RootSc.x;
                   imageHeadSc.Y = RootSc.y;
               }
               ImVec4 rect((imageHeadSc.X) - 80, imageHeadSc.Y - 50, 160, 25);
               draw->AddImage(
                   WeaponImage[44].textureId,
                   ImVec2(HeadSc.x + 200 - qtWidth + 1, HeadSc.y - 25 - iconsize - 5 - qtHeight + 1),
                   ImVec2(HeadSc.x + 200 - qtWidth + 1 + qtHeight - 2, HeadSc.y - 25 - iconsize - 5 - qtHeight + qtHeight - 1),
                   ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f)
               );
               foundWeaponIcon = true;
           } else {
               // Try to find a matching icon in the table
               for (const auto& entry : weaponIconTable) {
                   if (IsWeaponVariant(weaponId, entry.ids)) {
                       DrawWeaponIcon(*entry.textureInfo);
                       foundWeaponIcon = true;
                       break;
                   }
               }
           }
       }

       // If no icon found, fallback to "fist"
       if (!foundWeaponIcon) {
           DrawWeaponIcon(ID拳头);
       }
   }
   // End of improved, safer, and less buggy weapon icon rendering
    

    // Improved, safer, and more robust distance display
    if (Config.Distance) {
        // Defensive: Clamp distance to a reasonable range (0-9999)
        int displayDistance = static_cast<int>(std::max(0.0f, std::min(Distance, 9999.0f)));
        std::string str = std::to_string(displayDistance) + " m";

        // Use ImGui::CalcTextSize for accurate text centering, with fallback if needed
        ImVec2 textSizes = ImGui::CalcTextSize(str.c_str(), nullptr, false, 35.0f);

        // Clamp RootSc.x/y to screen bounds if available (optional, for safety)
        float textX = RootSc.x - (textSizes.x / 2.0f);
        float textY = RootSc.y + 15.0f;

        // Use a shadow for better readability
        ImColor mainColor(255, 200, 0, 255);
        ImColor shadowColor(0, 0, 0, 180);
        float shadowOffset = 1.5f;

        // Draw shadow first
        Fly_Draw->DrawStrokeText(textX + shadowOffset, textY + shadowOffset, shadowColor, str.c_str());
        // Draw main text
        Fly_Draw->DrawStrokeText(textX, textY, mainColor, str.c_str());
    }

                            
 
}}}//3

                    // Improved, safer, and less buggy grenade warning rendering
                    // Defensive: Check for invalid objects first
                    if (isObjectInvalid(Actors[i])) {
                        continue;
                    }

                    // Only process grenades if enabled in config
                    if (Config.GrenadeW && isObjectGrenade(Actors[i])) {
                        auto* Grenade = static_cast<ASTExtraGrenadeBase*>(Actors[i]);
                        if (!Grenade) continue; // Defensive: null check

                        std::string grenadePath = getObjectPath(Grenade);
                        auto* RootComponent = Actors[i]->RootComponent;
                        if (!RootComponent) {
                            continue;
                        }

                        float Distance = 0.0f;
                        if (localPlayer) {
                            Distance = Grenade->GetDistanceTo(localPlayer) / 100.f;
                        }

                        FVector2D Location;
                        // Use grenade's world location for screen projection
                        if (WorldToScreenBone(Grenade->K2_GetActorLocation(), &Location)) {
                            // Only show warning for grenades within 100m
                            if (Distance <= 100.f) {
                                // Known grenade types
                                constexpr const char* MolotovPath = "BP_Grenade_Burn_C.BP_Grenade_Base_C.STExtraGrenadeBase.UAEProjectile.LuaActor.Actor.Object";
                                constexpr const char* FragPath    = "BP_Grenade_Shoulei_C.BP_Grenade_Base_C.STExtraGrenadeBase.UAEProjectile.LuaActor.Actor.Object";

                                bool isMolotov = (grenadePath == MolotovPath);
                                bool isFrag    = (grenadePath == FragPath);

                                // Show a big warning at the top for dangerous grenades
                                if (isMolotov || isFrag) {
                                    // Draw a large warning at the top center of the screen
                                    draw->AddText(
                                        Chinese,
                                        50.0f,
                                        ImVec2(glWidth / 2.0f - 112.0f, 250.0f),
                                        IM_COL32(255, 0, 0, 255),
                                        "WARNING...!!!"
                                    );
                                }

                                // Compose grenade label
                                std::string label;
                                if (isMolotov) {
                                    label = "Molotov";
                                } else if (isFrag) {
                                    label = "Grenade";
                                } else {
                                    // For unknown grenades, show generic label
                                    label = "Grenade";
                                }
                                label += " - [";
                                label += std::to_string(static_cast<int>(Distance));
                                label += "M]";

                                // Draw grenade label at grenade position
                                draw->AddText(
                                    nullptr, // Use default font for clarity
                                    30.0f,
                                    ImVec2(Location.X, Location.Y),
                                    IM_COL32(255, 0, 0, 255),
                                    label.c_str()
                                );
                            }
                        }
                    }
                    
                    // Improved, refactored, and less buggy loot ESP code
                    if (isObjectLoot(Actors[i])) {
                        auto* PickUp = static_cast<APickUpWrapperActor*>(Actors[i]);
                        if (!PickUp) continue;

                        auto* RootComponent = PickUp->RootComponent;
                        if (!RootComponent) continue;

                        std::string classname = PickUp->GetName();
                        if (classname.empty()) continue;

                        float Distance = PickUp->GetDistanceTo(localPlayer) / 100.f;
                        if (Distance > 100.f) continue;

                        int wppp = PickUp->DefineID.TypeSpecificID;

               // Color definitions
               constexpr int m4     = 0xFFD1EEEE;
               constexpr int ak     = 0xFFFCC89D;
               constexpr int lvmax  = 0xFFFFF266;
               constexpr int smg    = 0xFF919AFF;
               constexpr int sniper = 0xFFFCC89D;

               FVector2D Location;
               if (!WorldToScreenBone(PickUp->K2_GetActorLocation(), &Location)) continue;



               // All loot definitions (add more as needed)
               static const int M416_IDS[]    = {101004,1010041,1010042,1010043,1010044,1010045,1010046,1010047};
               static const int AKM_IDS[]     = {101001,1010011,1010012,1010013,1010014,1010015,1010016,1010017};
               static const int SCARL_IDS[]   = {101003,1010031,1010032,1010033,1010034,1010035,1010036,1010037};
               static const int ACE32_IDS[]   = {101102,1011021,1011022,1011023,1011024,1011025,1011026,1011027};
               static const int GROZA_IDS[]   = {101005,1010051,1010052,1010053,1010054,1010055,1010056,1010057};
               static const int AUG_IDS[]     = {101006,1010061,1010062,1010063,1010064,1010065,10100166,1010067};
               static const int QBZ_IDS[]     = {101007,1010071,1010072,1010073,1010074,1010075,10100176,1010077};
               static const int M762_IDS[]    = {101008,1010081,1010082,1010083,1010084,1010085,1010086,1010087};
               static const int G36C_IDS[]    = {101010,1010101,1010102,1010103,1010104,1010105,1010106,1010107};
               static const int FAMAS_IDS[]   = {101100,1011001,1011002,1011003,1011004,1011005,1011006,1011007};
               static const int M249_IDS[]    = {105001,1050011,1050012,1050013,1050014,1050015,1050016,1050017};
               static const int DP28_IDS[]    = {105002,1050021,1050022,1050023,1050024,1050025,1050026,1050027};
               static const int UZI_IDS[]     = {102001,1020011,1020012,1020013,1020014,1020015};
               static const int UMP45_IDS[]   = {102002,1020021,1020022,1020023,1020024,1020025};
               static const int VECTOR_IDS[]  = {102003,1020031,1020032,1020033,1020034,1020035,1020036,1020037};
               static const int TOMMY_IDS[]   = {102004,1020041,1020042,1020043,1020044,1020045,1020046,1020047};
               static const int BIZON_IDS[]   = {102005,1020051,1020052,1020053,1020054,1020055,1020056,1020057};
               static const int P90_IDS[]     = {102105,1021051,1021052,1021053,1021054,1021055,1021056,1021057};
               static const int SKORPION_IDS[]= {102007,1020071,1020072,1020073,1020074,1020075,1020076,1020077};
               static const int KAR98K_IDS[]  = {103001,1030011,1030012,1030013,1030014,1030015,1030016,1030017};
               static const int M24_IDS[]     = {103002,1030021,1030022,1030023,1030024,1030025,1030026,1030027};
               static const int AWM_IDS[]     = {103003,1030031,1030032,1030033,1030034,1030035,1030036,1030037};
               static const int AMR_IDS[]     = {103012,1030121,1030122,1030123,1030124,1030125,1030126,1030127};
               static const int MM556_IDS[]   = {303001,3030011,3030012,3030013,3030014,3030015,3030016};
               static const int MM762_IDS[]   = {302001,3020011,3020012,3020013,3020014,3020015,3020016};
               static const int MM9_IDS[]     = {301001,3010011,3010012,3010013,3010014,3010015,3010016};
               static const int ACP45_IDS[]   = {305001,3050011,3050012,3050013,3050014,3050015,3050016};
               static const int BAG_IDS[]     = {501006,501103,501104,501105,501106};
               static const int ARMOR_IDS[]   = {503003,503103,503104,503105,503106,503107,503108,503109,503110,503111,503112};
               static const int HELMET_IDS[]  = {502003,502103,502104,502105,502106,502107,502108,502109,502110,502111,502112};

               // List of loot to display
               const LootInfo lootTable[] = {
                   {"M416",      M416_IDS,    std::size(M416_IDS),    m4,     Config.M416},
                   {"AKM",       AKM_IDS,     std::size(AKM_IDS),     ak,     Config.AKM},
                   {"SCAR-L",    SCARL_IDS,   std::size(SCARL_IDS),   m4,     Config.SCARL},
                   {"ACE32",     ACE32_IDS,   std::size(ACE32_IDS),   ak,     Config.ACE32},
                   {"Groza",     GROZA_IDS,   std::size(GROZA_IDS),   ak,     Config.Groza},
                   {"AUG",       AUG_IDS,     std::size(AUG_IDS),     m4,     Config.AUG},
                   {"QBZ",       QBZ_IDS,     std::size(QBZ_IDS),     m4,     Config.QBZ},
                   {"M762",      M762_IDS,    std::size(M762_IDS),    ak,     Config.M762},
                   {"G36C",      G36C_IDS,    std::size(G36C_IDS),    ak,     Config.G36C},
                   {"FAMAS",     FAMAS_IDS,   std::size(FAMAS_IDS),   m4,     Config.FAMAS},
                   {"M249",      M249_IDS,    std::size(M249_IDS),    m4,     Config.M249},
                   {"DP-28",     DP28_IDS,    std::size(DP28_IDS),    ak,     Config.DP28},
                   {"UZI",       UZI_IDS,     std::size(UZI_IDS),     smg,    Config.UZI},
                   {"UMP-45",    UMP45_IDS,   std::size(UMP45_IDS),   smg,    Config.UMP45},
                   {"Vector",    VECTOR_IDS,  std::size(VECTOR_IDS),  smg,    Config.Vector},
                   {"TommyGun",  TOMMY_IDS,   std::size(TOMMY_IDS),   smg,    Config.TommyGun},
                   {"PP-19 Bizon",BIZON_IDS,  std::size(BIZON_IDS),   smg,    Config.PP19Bizon},
                   {"P90",       P90_IDS,     std::size(P90_IDS),     smg,    Config.P90},
                   {"Skorpion",  SKORPION_IDS,std::size(SKORPION_IDS),smg,   Config.Skorpion},
                   {"Kar98K",    KAR98K_IDS,  std::size(KAR98K_IDS),  sniper, Config.Kar98K},
                   {"M24",       M24_IDS,     std::size(M24_IDS),     sniper, Config.M24},
                   {"AWM",       AWM_IDS,     std::size(AWM_IDS),     sniper, Config.AWM},
                   {"AMR",       AMR_IDS,     std::size(AMR_IDS),     sniper, Config.AMR},
                   {"5.56mm",    MM556_IDS,   std::size(MM556_IDS),   m4,     Config.mm556},
                   {"7.62mm",    MM762_IDS,   std::size(MM762_IDS),   ak,     Config.mm762},
                   {"9mm",       MM9_IDS,     std::size(MM9_IDS),     smg,    Config.mm9},
                   {".45 ACP",   ACP45_IDS,   std::size(ACP45_IDS),   smg,    Config.ACP45},
                   {"Bag",       BAG_IDS,     std::size(BAG_IDS),     lvmax,  Config.Bag},
                   {"Armor",     ARMOR_IDS,   std::size(ARMOR_IDS),   lvmax,  Config.Armor},
                   {"Helmet",    HELMET_IDS,  std::size(HELMET_IDS),  lvmax,  Config.Helmet},
               };

               // Find and draw loot
               for (const auto& loot : lootTable) {
                   if (!loot.enabled) continue;
                   for (size_t j = 0; j < loot.id_count; ++j) {
                       if (wppp == loot.ids[j]) {
                           std::string label = loot.name;
                           label += " [";
                           label += std::to_string(static_cast<int>(Distance));
                           label += "M]";
                           draw->AddText(nullptr, 30.0f, {Location.X, Location.Y}, loot.color, label.c_str());
                           break; // Only draw once per item
                       }
                   }
               }
           }
                        
                        
                        
                        
                        
                                //if (isObjectLootBox(Actors[i])) {
                                   /*
             if (Actors[i]->IsA(APickUpListWrapperActor::StaticClass())) {
                        auto PickUpList = (APickUpListWrapperActor *) Actors[i];
                     
                     
                     */

                    
                    // Improved, safer, and less buggy loot box ESP rendering
                    if (isObjectLootBox(Actors[i])) {
                        // Defensive: check pointer validity before use
                        auto* PickUpList = dynamic_cast<APickUpListWrapperActor*>(Actors[i]);
                        if (!PickUpList) continue;

                        if (Config.EspLootBox) {
                            // Defensive: check RootComponent before use
                            auto* RootComponent = PickUpList->RootComponent;
                            if (!RootComponent) continue;

                            // Get loot box screen position
                            FVector2D screenPos;
                            bool hasScreenPos = WorldToScreenBone(PickUpList->K2_GetActorLocation(), &screenPos);
                            if (!hasScreenPos) continue;

                            // Calculate distance to local player (defensive: check localPlayer)
                            float distance = 0.0f;
                            if (localPlayer) {
                                distance = PickUpList->GetDistanceTo(localPlayer) / 100.f;
                            }

                            // Only show loot box ESP within a reasonable distance
                            constexpr float kMaxLootBoxDistance = 50.0f;
                            if (distance > 0.0f && distance <= kMaxLootBoxDistance) {
                                std::string label = "Box [" + std::to_string(static_cast<int>(distance)) + "m]";
                                // Draw with shadow for readability
                                ImU32 boxColor = IM_COL32(0, 255, 0, 255);
                                ImU32 shadowColor = IM_COL32(0, 0, 0, 180);
                                ImVec2 textPos(screenPos.X, screenPos.Y);

                                // Shadow
                                draw->AddText(nullptr, 30.0f, {textPos.x + 1, textPos.y + 1}, shadowColor, label.c_str());
                                // Main text
                                draw->AddText(nullptr, 30.0f, textPos, boxColor, label.c_str());
                            }
                        }
                    }

                    // Improved, safer, and less buggy vehicle ESP rendering
                    if (isObjectVehicle(Actors[i])) {
                        // Use dynamic_cast for type safety
                        auto* Vehicle = dynamic_cast<ASTExtraVehicleBase*>(Actors[i]);
                        if (!Vehicle) continue;

                        if (Config.EspCar) {
                            // Defensive: check RootComponent and localPlayer before use
                            auto* RootComponent = Vehicle->RootComponent;
                            if (!RootComponent || !localPlayer) continue;

                            // Calculate distance to local player
                            float vDistance = Vehicle->GetDistanceTo(localPlayer) / 100.f;

                            // Only show vehicle ESP within a reasonable distance (e.g., 500m)
                            constexpr float kMaxVehicleDistance = 500.0f;
                            if (vDistance > 0.0f && vDistance <= kMaxVehicleDistance) {
                                FVector2D screenPos;
                                if (WorldToScreenBone(Vehicle->K2_GetActorLocation(), &screenPos)) {
                                    std::string label = GetVehicleName(Vehicle);
                                    label += " [";
                                    label += std::to_string(static_cast<int>(vDistance));
                                    label += "m]";

                                    // Draw with shadow for readability
                                    ImU32 vehicleColor = IM_COL32(255, 50, 255, 255);
                                    ImU32 shadowColor = IM_COL32(0, 0, 0, 180);
                                    ImVec2 textPos(screenPos.X, screenPos.Y);

                                    // Shadow
                                    draw->AddText(nullptr, 30.0f, {textPos.x + 1, textPos.y + 1}, shadowColor, label.c_str());
                                    // Main text
                                    draw->AddText(nullptr, 30.0f, textPos, vehicleColor, label.c_str());
                                }
                            }
                        }
                    }
        
                    

//}
}
}

/*
sprintf(extra,  "Memory: %.0f MB (%.2f GB)", available_memory_mb, total_memory_gb);
draw->AddText(nullptr, 40.0f, ImVec2(110, (float) glHeight - 84), IM_COL32(255, 255, 255, 255),extra);
*/
//if (localPlayerController) {
/*
std::string s;
            if (totalEnemies + totalBots < 10)
                s += "";
            else s += "";
            s += std::to_string((int) totalEnemies + totalBots);
            draw->AddText(nullptr, 70, ImVec2(glWidth / 2  - 10.f, 70), IM_COL32(255, 0, 0, 255), s.c_str());
          //  }
            */
//8.5f
            
            
{
    
    
      draw->AddImage(Base64Image[1].textureId, ImVec2(glWidth / 2-115 - 50 / 2, 115), ImVec2(glWidth / 2-115 + 50 / 2, 115 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
        draw->AddImage(Base64Image[2].textureId, ImVec2(glWidth / 2+115 - 50 / 2, 115), ImVec2(glWidth / 2+115 + 50 / 2, 115 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
         if (totalEnemies == 0 && totalBots == 0) {
        draw->AddImage(Base64Image[3].textureId, ImVec2(glWidth / 2 - 50 / 2, 114), ImVec2(glWidth / 2 + 50 / 2, 114 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
         }else{
         
        if(totalBots == 0){
            draw->AddTextX(ImVec2(glWidth / 2 + 36.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255),45, std::to_string(totalBots).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 + 35, 100 + 50 / 2 - 5), ImColor(0, 255, 0), 45, std::to_string(totalBots).c_str());
           }else{
        draw->AddTextX(ImVec2(glWidth / 2 + 36.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255),45, std::to_string(totalBots).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 + 35, 100 + 50 / 2 - 5), ImColor(255, 255, 0), 45, std::to_string(totalBots).c_str());
                draw->AddImage(Base64Image[4].textureId, ImVec2(glWidth / 2 - 50 / 2, 114), ImVec2(glWidth / 2 + 50 / 2, 114 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
        }
         if(totalEnemies == 0){
             draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(totalEnemies).c_str(), 40) - 33.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255), 45, std::to_string(totalEnemies).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(totalEnemies).c_str(), 40) - 35, 100 + 50 / 2 - 5), ImColor(0, 255, 0), 45, std::to_string(totalEnemies).c_str());
                  }else{
                      draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(totalEnemies).c_str(), 40) - 33.5, 101.5 + 50 / 2 - 5), ImColor(0, 0, 0, 255), 45, std::to_string(totalEnemies).c_str());
                draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize(std::to_string(totalEnemies).c_str(), 40) - 35, 100 + 50 / 2 - 5), ImColor(255, 0, 0), 45, std::to_string(totalEnemies).c_str());
                draw->AddImage(Base64Image[5].textureId, ImVec2(glWidth / 2 - 50 / 2, 114), ImVec2(glWidth / 2 + 50 / 2, 114 + 50), ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f));
                      }
        }
        


}

//}
       //   }

  if (Config.AimEnable){
        if (!Config.HideFov){
draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), Config.AimFov,IM_COL32(255, 255, 255, 255), 10000, 2.0f);
}
  }


  }
  
  
     
     {
         draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize( "BEAR-ENGINE", 20.5f) - 3.5, 101.5 + 50 / 2 + 50), ImColor(0, 0, 0, 255),50, "BEAR-ENGINE");
        draw->AddTextX(ImVec2(glWidth / 2 - calcTextSize( "BEAR-ENGINE", 20.5f) - 5, 100 + 50 / 2 + 50), ImColor(255, 255, 255), 50, "BEAR-ENGINE");
         
         
     }
  }}
