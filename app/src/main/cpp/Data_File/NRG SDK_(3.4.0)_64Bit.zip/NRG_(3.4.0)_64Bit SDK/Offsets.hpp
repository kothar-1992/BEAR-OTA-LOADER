#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:19 2024
 
 
 
PUBG MOBILE GL,KR,TW 3.4.0 64 BIT

GName Offset 0xc7d2e80
GWorld Offset 0xc814fa0
VWorld Offset 0xce8cfd0
VMatrix Offset 0xce93a70

PostRender 0x8ca5ee8
K2_DrawText 0x921f90c
K2_DrawLine 0x921f67c

#define ShortEvent_Offset 0x5ab8148 //Hook For BT
#define GNames_Offset 0x713833c
#define GEngine_Offset 0xce93a70 //ULocalPlayer
#define GEngine_Offset 0xceb4578 //UEngine
#define GUObject_Offset 0xcc5d670
#define GetActorArray_Offset 0x8d6d814
#define CanvasMap_Offset 0xc894da0
#define ProcessEvent_Offset 0x73982a8 
#define GNativeAndroidApp_Offset 0xc7d2a08
#define Actors_Offset 0xa0

 
 
 
 
#define GWorld 0x0; // World
#define GName 0x0; // TStaticIndirectArrayThreadSafeRead
#define GObjectArray 0x0; // FUObjectArray



#define Engine_LocalPlayer 0x1; // Engine
#define Actor_RootComponent 0x1b0; // Actor
#define Actor_bHidden 0x88; // Actor
#define SceneComponent_ComponentVelocity 0x260; // SceneComponent
#define SceneComponent_RelativeLocation 0x184; // SceneComponent
#define PrimitiveComponent_LastRenderTime 0x410; // PrimitiveComponent
#define MovementComponent_Velocity 0x12c; // MovementComponent
#define Character_Mesh 0x498; // Character
#define UAECharacter_bEnsure 0x9e9; // UAECharacter
#define UAECharacter_bIsAI 0x9d0; // UAECharacter
#define UAECharacter_TeamID 0x938; // UAECharacter
#define UAECharacter_PlayerUID 0x918; // UAECharacter
#define UAECharacter_PlayerKey 0x910; // UAECharacter
#define UAECharacter_Nation 0x900; // UAECharacter
#define UAECharacter_PlayerName 0x8f0; // UAECharacter
#define STExtraCharacter_bIsGunADS 0x1059; // STExtraCharacter
#define STExtraCharacter_PartHitComponent 0x1050; // STExtraCharacter
#define STExtraCharacter_CurrentStates 0xf88; // STExtraCharacter
#define STExtraCharacter_CurrentVehicle 0xe08; // STExtraCharacter
#define STExtraCharacter_bDead 0xddc; // STExtraCharacter
#define STExtraCharacter_HealthMax 0xdc4; // STExtraCharacter
#define STExtraCharacter_Health 0xdc0; // STExtraCharacter
#define WeaponManagerComponent_CurrentWeaponReplicated 0x500; // WeaponManagerComponent
#define STExtraVehicleBase_VehicleShapeType 0x654; // STExtraVehicleBase
#define STExtraWeapon_WeaponEntityComp 0x848; // STExtraWeapon
#define STExtraBaseCharacter_VehicleSeatIdx 0x2ad0; // STExtraBaseCharacter
#define STExtraBaseCharacter_WeaponManagerComponent 0x2328; // STExtraBaseCharacter
#define STExtraBaseCharacter_STCharacterMovement 0x1bf8; // STExtraBaseCharacter
#define STExtraBaseCharacter_NearDeathBreath 0x1980; // STExtraBaseCharacter
#define STExtraBaseCharacter_NearDeatchComponent 0x1960; // STExtraBaseCharacter
#define STExtraBaseCharacter_bIsWeaponFiring 0x1640; // STExtraBaseCharacter
#define PickUpWrapperActor_bCanBePickUp 0x58c; // PickUpWrapperActor
#define PickUpWrapperActor_Count 0x588; // PickUpWrapperActor
#define PickUpWrapperActor_DefineID 0x570; // PickUpWrapperActor
#define MinimalViewInfo_FOV 0x24; // MinimalViewInfo
#define MinimalViewInfo_Rotation 0x18; // MinimalViewInfo
#define MinimalViewInfo_Location 0x0; // MinimalViewInfo
#define STExtraPlayerCharacter_STPlayerController 0x3fc0; // STExtraPlayerCharacter
#define Controller_ControlRotation 0x468; // Controller
#define Controller_TransformComponent 0x460; // Controller
#define STExtraGameStateBase_GameID 0xfc0; // STExtraGameStateBase
#define STExtraGameStateBase_PlayerNumPerTeam 0xe5c; // STExtraGameStateBase
#define STExtraGameStateBase_AliveTeamNum 0xa88; // STExtraGameStateBase
#define STExtraGameStateBase_AlivePlayerNum 0xa84; // STExtraGameStateBase
#define STExtraGameStateBase_PlayerNum 0x740; // STExtraGameStateBase
#define PlayerController_PlayerCameraManager 0x4d0; // PlayerController
#define PlayerController_MyHUD 0x4c8; // PlayerController
#define PlayerController_AcknowledgedPawn 0x4b0; // PlayerController
#define UAEPlayerController_TeamID 0x8a8; // UAEPlayerController
#define UAEPlayerController_PlayerKey 0x888; // UAEPlayerController
#define UAEPlayerController_PlayerName 0x878; // UAEPlayerController
#define STExtraPlayerController_BroadcastFatalDamageToClientWithStruct 0x1; // STExtraPlayerController
#define STExtraPlayerController_bIsPressingFireBtn 0x3548; // STExtraPlayerController
#define STExtraPlayerController_STExtraBaseCharacter 0x2640; // STExtraPlayerController
#define STExtraPlayerController_CurCameraMode 0x2588; // STExtraPlayerController
#define PickUpListWrapperActor_PickUpDataList 0x880; // PickUpListWrapperActor
#define STExtraShootWeaponBulletBase_PMComp 0x550; // STExtraShootWeaponBulletBase
#define CameraCacheEntry_POV 0x10; // CameraCacheEntry
#define StaticMeshComponent_StaticMesh 0x878; // StaticMeshComponent
#define StaticMeshComponent_MinLOD 0x874; // StaticMeshComponent
#define PetEntityComponent_FixAttachInfoList 0x1a0; // PetEntityComponent
#define CharacterMovementComponent_LastUpdateVelocity 0x2d0; // CharacterMovementComponent
#define CharacterMovementComponent_LastUpdateRotation 0x2c0; // CharacterMovementComponent
#define CharacterMovementComponent_LastUpdateLocation 0x2b4; // CharacterMovementComponent
#define CharacterMovementComponent_JumpZVelocity 0x1bc; // CharacterMovementComponent
#define ShootWeaponEntity_AccessoriesDeviationFactor 0xb98; // ShootWeaponEntity
#define ShootWeaponEntity_GameDeviationAccuracy 0xb94; // ShootWeaponEntity
#define ShootWeaponEntity_GameDeviationFactor 0xb90; // ShootWeaponEntity
#define ShootWeaponEntity_ShotGunHorizontalSpread 0xb8c; // ShootWeaponEntity
#define ShootWeaponEntity_ShotGunVerticalSpread 0xb88; // ShootWeaponEntity
#define ShootWeaponEntity_ShotGunCenterPerc 0xb84; // ShootWeaponEntity
#define ShootWeaponEntity_RecoilInfo 0xaa8; // ShootWeaponEntity
#define ShootWeaponEntity_bHasAutoFireMode 0x591; // ShootWeaponEntity
#define ShootWeaponEntity_BulletFireSpeed 0x4f8; // ShootWeaponEntity
#define ShootWeaponEntity_BulletTemplate 0x4f0; // ShootWeaponEntity
#define SkeletalMeshComponent_CachedComponentSpaceTransforms 0xb10; // SkeletalMeshComponent
#define SkeletalMeshComponent_CachedBoneSpaceTransforms 0xb00; // SkeletalMeshComponent
#define STCharacterMovementComponent_WalkSpeedCurveScale 0xb28; // STCharacterMovementComponent
#define STCharacterNearDeathComp_BreathMax 0x16c; // STCharacterNearDeathComp
#define NetDriver_ServerConnection 0x78; // NetDriver
#define PlayerCameraManager_CameraCache 0x4b0; // PlayerCameraManager
#define Engine_GameViewport 0x810; // Engine
#define GameViewportClient_World 0x78; // GameViewportClient
#define LocalPlayer_AspectRatioAxisConstraint 0x7c; // LocalPlayer
#define World_LevelCollections 0x200; // World
#define World_NetDriver 0x38; // World
#define World_PersistentLevel 0x30; // World


// ShadowTrackerExtra.CharacterOverrideAttrs.GameModeOverride_SpeedScaleModifier Not Found
// Gameplay.UAEPlayerController.UId Not Found
// Gameplay.WeaponAttrReloadTableStruct.RecoilKickADS Not Found
// Gameplay.WeaponAttrReloadTableStruct.AccessoriesRecoveryFactor Not Found
// Gameplay.WeaponAttrReloadTableStruct.AccessoriesVRecoilFactor Not Found
// ShadowTrackerExtra.STExtraGameStateBase.ElapsedTime Not Found
// Gameplay.WeaponAttrReloadTableStruct.AccessoriesHRecoilFactor Not Found
// Found 87 offsets of 94
