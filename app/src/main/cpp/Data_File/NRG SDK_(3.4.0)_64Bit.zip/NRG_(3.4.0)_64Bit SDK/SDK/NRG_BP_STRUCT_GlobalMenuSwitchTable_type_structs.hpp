#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:19 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_GlobalMenuSwitchTable_type.BP_STRUCT_GlobalMenuSwitchTable_type
// 0x0008
struct FBP_STRUCT_GlobalMenuSwitchTable_type
{
	int                                                ID_0_14E478C009E418DF06E7F5440259BAA4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_1_4FBB1A0034F5B7D2525FA9D509BB14EE;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

