#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:19 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_PlaneBPTable_type.BP_STRUCT_PlaneBPTable_type
// 0x0038
struct FBP_STRUCT_PlaneBPTable_type
{
	int                                                ID_0_59EBC34020F2CB575FD7DA4501D5C5E4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Path_1_6A746340179EA83F75000E8B05C45978;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_2_5267910037561B4A1C0638D70C555B65;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyPath_3_11D881407290252D3B3DCF9705C20AE8;             // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

