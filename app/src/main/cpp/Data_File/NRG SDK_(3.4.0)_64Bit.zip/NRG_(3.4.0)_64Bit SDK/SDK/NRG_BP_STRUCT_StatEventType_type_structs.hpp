#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:19 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_StatEventType_type.BP_STRUCT_StatEventType_type
// 0x0014
struct FBP_STRUCT_StatEventType_type
{
	struct FString                                     DisplayName_0_7D516B402CBFB7AB2A776EB00D8D1405;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_1_49A788C0256E4AF90B9DAE5205E4F254;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

