#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:17 2024
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
struct ULuaHotReloadHelper_OnLuaFileHotUpdate_Params
{
	struct FString                                     NotifyMessage;                                            // (Parm, ZeroConstructor)
};

}

