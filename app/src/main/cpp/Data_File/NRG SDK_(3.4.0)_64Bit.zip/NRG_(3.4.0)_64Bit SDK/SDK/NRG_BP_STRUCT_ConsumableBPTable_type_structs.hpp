#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:19 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_ConsumableBPTable_type.BP_STRUCT_ConsumableBPTable_type
// 0x0048
struct FBP_STRUCT_ConsumableBPTable_type
{
	struct FString                                     CName_0_3A46A7E346B57C4E5F45619DF5906006;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_1_81463AA644426E53AF3240A311C1D4E0;                  // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_AD337FD040A1235FE67F55BBA677262B;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     Wrapper_3_66935E806EA99C4E6B9844A505FF3052;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyPath_4_60DFC780056E426A3B985A350FD8F288;             // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

