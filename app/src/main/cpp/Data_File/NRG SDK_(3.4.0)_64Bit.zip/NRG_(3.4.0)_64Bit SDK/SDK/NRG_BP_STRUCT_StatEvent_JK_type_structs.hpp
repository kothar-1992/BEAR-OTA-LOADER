#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:19 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_StatEvent_JK_type.BP_STRUCT_StatEvent_JK_type
// 0x0025
struct FBP_STRUCT_StatEvent_JK_type
{
	struct FString                                     adjustAndroidToken_0_4049FD4079E8B5315CC62FE10F92091E;    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     adjustIOSToken_1_6D79C7C0046E4DBD63310F3C0A96CEDE;        // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_2_07A87D407C33595F793EC06707034704;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               unique_3_2521AFC01FC88CC56D1C21EC06540BF5;                // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

