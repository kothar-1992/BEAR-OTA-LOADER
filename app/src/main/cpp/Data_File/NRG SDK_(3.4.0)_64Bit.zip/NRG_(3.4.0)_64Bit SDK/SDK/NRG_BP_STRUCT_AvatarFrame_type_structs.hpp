#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:18 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_AvatarFrame_type.BP_STRUCT_AvatarFrame_type
// 0x00BC
struct FBP_STRUCT_AvatarFrame_type
{
	int                                                Type_0_1A0A9F0743331BBE49AADB988DC87C90;                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Desc_1_AC45D7034D7DDDC90D52E19BF6D66EF9;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Name_2_401DF90F47F3FF259DF5AD890925B071;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_3_831225F64111B05931B2D0B74884A6BD;                    // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FString                                     DescGet_4_E78748484096828FA71D5E85901FD57B;               // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     IconBig_5_82F9A60A40DA032B376321A0896F07F2;               // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Icon_6_7C7ADBE24A1E2C45A54BC7BD91D84759;                  // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DescTime_7_684743074A1D090755252DAA2F6832B5;              // 0x0060(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                AppleAuditHide_8_C3DCAE874E4C89FB670303A48501283C;        // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                DefaultDisplay_9_43871EC03BAE8EB1607A95390AB61819;        // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ShowTime_10_6F3484001A56164C305DF94C07184815;             // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     JumpUrl_11_6CA1ABC05B25AE9F2E15463A0A43122C;              // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DynamicIcon_12_3606CB802735CB58611D23940D677B1E;          // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DynamicIconBig_13_71663000078E7FEE57C61E8607B2FE87;       // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TimeFilterId_14_13EA6080507119E0664884F808228BD4;         // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

