#pragma once

// PUBG MOBILE (3.4.0) 64bit (Telegram : @TEAMNRG1)  
// Thu Sep 12 01:30:18 2024
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_TransSupportConfig_JK_type.BP_STRUCT_TransSupportConfig_JK_type
// 0x0038
struct FBP_STRUCT_TransSupportConfig_JK_type
{
	struct FString                                     languageCode_0_522E49002C2C60AE700EB3710A85F6D5;          // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     abbreviation_1_383E76C0511890B155CEDC5000FC0B5E;          // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                languageID_2_64A28D80497B830E04CE3D52037A85A4;            // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               isSupported_3_24C9E1C053F6E8A95BD1A1D30BC1D3A4;           // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
	struct FString                                     displayName_4_766D5700151549701BF7326D0E448FF5;           // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

